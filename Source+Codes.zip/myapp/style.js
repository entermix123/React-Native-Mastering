//styling
import { StyleSheet } from "react-native";
const Styles = StyleSheet.create({
  //   container: {
  //     color: "red",
  //   },
  //   second: {
  //     color: "red",
  //     backgroundColor: "green",
  //     height: 500,
  //     justifyContent: "center",
  //   },
  //   text: {
  //     fontWeight: "bold",
  //     textAlign: "center",
  //   },
});
export default Styles;
