import { StyleSheet, Text, View } from "react-native";
import React from "react";
const New = () => {
  return (
    <View>
      <Text>new</Text>
    </View>
  );
};

export default New;

const styles = StyleSheet.create({});
